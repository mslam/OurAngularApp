import { Injectable } from '@angular/core';
import {Signupuser} from "../signupuser";
import {Loginuser} from '../loginuser';
@Injectable()
export class ContextService {

  constructor() { }

  public currentSignupuser: Signupuser;
  public currentLoginuser: Loginuser;
}
