export class Loginuser {
    constructor(
        public login_user_id: number,
        public login_user_name: string,
        public login_user_email: string,
        public login_user_password: string,
    ) {}
}
